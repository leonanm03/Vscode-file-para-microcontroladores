# C/C++ Extension Pack for Visual Studio Code Change Log

## Version 1.3.0
### List of extensions:
* C/C++
* C/C++ Themes
* CMake Tools
