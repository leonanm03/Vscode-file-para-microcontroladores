# Change Log
All notable changes to the "increment-selection" extension will be documented in this file.

## [0.1.0] - 2019-11-22
- Added reverse selection

## [0.0.8] - 2019-07-22
- Fix security vulnerabilities

## [0.0.7] - 2019-07-22
- Fix security vulnerabilities

## [0.0.6] - 2019-04-09
- Added handling of leading zeros 

## [0.0.5] - 2019-04-08
- Added default behaviour when nothing is selected

## [0.0.4] - 2019-03-07
- Fix security issues
- Added decrement selection 

## [0.0.3] - 2018-10-09
- Fix security issues

## [0.0.2] - 2018-03-10
- Fix Documentation

## [0.0.1] - 2018-03-09
- Initial release
